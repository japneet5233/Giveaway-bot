const discord = require("discord.js");

module.exports = {
  name: "help",
  category: "info",
  description: "HELP.JS",
  run: async (client, message, args) => {
    
    let embed = new discord.MessageEmbed()
    .setTitle(`Help Documents Overview:`)
    .setDescription("**Commands**\n\nstart, reroll, end")
    .setColor("#010101")
    .setFooter(`Giveawy Boat`)
  .setTimestamp(message.timestamp = Date.now())
    
    message.channel .send(embed)
    
  
  }
}